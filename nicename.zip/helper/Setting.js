module.exports = {
  Agent1_key: process.env.AGENT1_KEY || '',
  Agent1_bot_id: process.env.AGENT1_BOT_ID || '',
  user_id: process.env.USER_ID || ''
};
